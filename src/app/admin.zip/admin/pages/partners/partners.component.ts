import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessService } from '../../../core/services/business.service';
import { Partner } from '../../../core/models/business.models';

@Component({
  selector: 'app-partners',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './partners.component.html',
 
})
export class PartnersComponent implements OnInit {

  private businessService = inject(BusinessService);

  partners: Partner[] = [];
  loading = false;
  showModal = false;
  isEdit = false;
  deleteId: number | null = null;
  showDeleteModal = false;

  form: Partner = { name: '', contactEmail: '', contactPhone: '' };

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.businessService.getPartners().subscribe({
      next: (data: Partner[]) => { this.partners = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate(): void {
    this.isEdit = false;
    this.form = { name: '', contactEmail: '', contactPhone: '' };
    this.showModal = true;
  }

  openEdit(p: Partner): void {
    this.isEdit = true;
    this.form = { ...p };
    this.showModal = true;
  }

  save(): void {
    if (this.isEdit && this.form.id) {
      this.businessService.updatePartner(this.form.id, this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    } else {
      this.businessService.createPartner(this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    }
  }

  confirmDelete(id: number): void {
    this.deleteId = id;
    this.showDeleteModal = true;
  }

  doDelete(): void {
    if (this.deleteId) {
      this.businessService.deletePartner(this.deleteId).subscribe(() => {
        this.showDeleteModal = false; this.deleteId = null; this.load();
      });
    }
  }
}