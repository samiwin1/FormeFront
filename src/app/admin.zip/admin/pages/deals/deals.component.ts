import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessService } from '../../../core/services/business.service';
import { Deal, Partner } from '../../../core/models/business.models';

@Component({
  selector: 'app-deals',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './deals.component.html',
  
})
export class DealsComponent implements OnInit {

  private businessService = inject(BusinessService);

  deals: Deal[] = [];
  partners: Partner[] = [];
  loading = false;
  showModal = false;
  isEdit = false;
  showDeleteModal = false;
  deleteId: number | null = null;

  form: Deal = { title: '', description: '', partnerId: 0, startDate: '', endDate: '' };

  ngOnInit(): void {
    this.load();
    this.businessService.getPartners().subscribe((p: Partner[]) => this.partners = p);
  }

  load(): void {
    this.loading = true;
    this.businessService.getDeals().subscribe({
      next: (data: Deal[]) => { this.deals = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getPartnerName(id: number): string {
    return this.partners.find(p => p.id === id)?.name ?? `#${id}`;
  }

  openCreate(): void {
    this.isEdit = false;
    this.form = { title: '', description: '', partnerId: 0, startDate: '', endDate: '' };
    this.showModal = true;
  }

  openEdit(d: Deal): void {
    this.isEdit = true;
    this.form = { ...d };
    this.showModal = true;
  }

  save(): void {
    if (this.isEdit && this.form.id) {
      this.businessService.updateDeal(this.form.id, this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    } else {
      this.businessService.createDeal(this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    }
  }

  confirmDelete(id: number): void {
    this.deleteId = id;
    this.showDeleteModal = true;
  }

  doDelete(): void {
    if (this.deleteId) {
      this.businessService.deleteDeal(this.deleteId).subscribe(() => {
        this.showDeleteModal = false; this.deleteId = null; this.load();
      });
    }
  }
}