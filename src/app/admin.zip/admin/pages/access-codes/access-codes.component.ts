import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessService } from '../../../core/services/business.service';
import { AccessCode, Partner, Deal } from '../../../core/models/business.models';

@Component({
  selector: 'app-access-codes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './access-codes.component.html'
})
export class AccessCodesComponent implements OnInit {

  private businessService = inject(BusinessService);

  accessCodes: AccessCode[] = [];
  partners: Partner[] = [];
  deals: Deal[] = [];
  loading = false;
  showModal = false;
  isEdit = false;
  showDeleteModal = false;
  deleteId: number | null = null;

  form: AccessCode = { code: '', partnerId: 0, dealId: 0, expirationDate: '', used: false };

  ngOnInit(): void {
    this.load();
    this.businessService.getPartners().subscribe((p: Partner[]) => this.partners = p);
    this.businessService.getDeals().subscribe((d: Deal[]) => this.deals = d);
  }

  load(): void {
    this.loading = true;
    this.businessService.getAccessCodes().subscribe({
      next: (data: AccessCode[]) => { this.accessCodes = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getPartnerName(id: number): string {
    return this.partners.find(p => p.id === id)?.name ?? `#${id}`;
  }

  getDealTitle(id: number): string {
    return this.deals.find(d => d.id === id)?.title ?? `#${id}`;
  }

  openCreate(): void {
    this.isEdit = false;
    this.form = { code: '', partnerId: 0, dealId: 0, expirationDate: '', used: false };
    this.showModal = true;
  }

  openEdit(a: AccessCode): void {
    this.isEdit = true;
    this.form = { ...a };
    this.showModal = true;
  }

  save(): void {
    if (this.isEdit && this.form.id) {
      this.businessService.updateAccessCode(this.form.id, this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    } else {
      this.businessService.createAccessCode(this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    }
  }

  confirmDelete(id: number): void {
    this.deleteId = id;
    this.showDeleteModal = true;
  }

  doDelete(): void {
    if (this.deleteId) {
      this.businessService.deleteAccessCode(this.deleteId).subscribe(() => {
        this.showDeleteModal = false; this.deleteId = null; this.load();
      });
    }
  }
}