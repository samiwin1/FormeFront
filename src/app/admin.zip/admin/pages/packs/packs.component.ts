import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessService } from '../../../core/services/business.service';
import { Pack } from '../../../core/models/business.models';

@Component({
  selector: 'app-packs',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './packs.component.html',
 
})
export class PacksComponent implements OnInit {

  private businessService = inject(BusinessService);

  packs: Pack[] = [];
  loading = false;
  showModal = false;
  isEdit = false;
  showDeleteModal = false;
  deleteId: number | null = null;

  form: Pack = { name: '', description: '', validityMonths: 1, active: true };

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.businessService.getPacks().subscribe({
      next: (data: Pack[]) => { this.packs = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate(): void {
    this.isEdit = false;
    this.form = { name: '', description: '', validityMonths: 1, active: true };
    this.showModal = true;
  }

  openEdit(p: Pack): void {
    this.isEdit = true;
    this.form = { ...p };
    this.showModal = true;
  }

  save(): void {
    if (this.isEdit && this.form.id) {
      this.businessService.updatePack(this.form.id, this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    } else {
      this.businessService.createPack(this.form).subscribe(() => {
        this.showModal = false; this.load();
      });
    }
  }

  confirmDelete(id: number): void {
    this.deleteId = id;
    this.showDeleteModal = true;
  }

  doDelete(): void {
    if (this.deleteId) {
      this.businessService.deletePack(this.deleteId).subscribe(() => {
        this.showDeleteModal = false; this.deleteId = null; this.load();
      });
    }
  }
}